The 15 files with prefix ex... are the Promela
files of all exercises and examples discussed
in http://spinroot.com/spin/Doc/Exercises.pdf
